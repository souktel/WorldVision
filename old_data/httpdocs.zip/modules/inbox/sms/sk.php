<?php
/**
 * Souktel v2.0
 * Developed By Tamer A. Qasim
 * +972(0)599358296
 * q.tamer@gmail.com
 */

/* 
 * Souktel Inbox Masking
 */

$ms_system = 1;
require_once("../inbox/sms/index.php");

?>
