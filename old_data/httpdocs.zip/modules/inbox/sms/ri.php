<?php
/**
 * Souktel v2.0
 * Developed By Tamer A. Qasim
 * +972(0)599358296
 * q.tamer@gmail.com
 */

/* 
 * Relief International Inbox Masking
 */

$ms_system = 16;
require_once("../inbox/sms/index.php");

?>
