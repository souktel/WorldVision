<?php
/**
 * Souktel v2.0
 * Developed By Tamer A. Qasim
 * +972(0)599358296
 * q.tamer@gmail.com
 */

/* 
 * JSC : GAZA Mini Survey Module
 */

$ms_system = 12;
require_once("../ms/sms/index.php");

?>
