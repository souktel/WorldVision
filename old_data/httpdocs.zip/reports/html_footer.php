</td>
<td width="20" background="<?php echo $param_abs_path_si;?>body-right_w.gif">&nbsp;</td>
</tr>
<tr>
    <td width="20" height="20" background="<?php echo $param_abs_path_si;?>body-lower-left_w.gif">&nbsp;</td>
    <td height="20" background="<?php echo $param_abs_path_si;?>body-lower_w.gif">&nbsp;</td>
    <td width="20" height="20" background="<?php echo $param_abs_path_si;?>body-lower-right_w.gif">&nbsp;</td>
</tr>
</table>
</body>
</html>
<?php
db_close($dbid);
?>