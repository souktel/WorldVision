<table border="0" width="724" cellpadding="0" style="border-collapse: collapse" background="<?php echo $param_abs_path_si;?>body-background.gif">
<tr>
<td width="20" height="20" background="<?php echo $param_abs_path_si;?>body-upper-left.gif">&nbsp;</td>
<td height="20" background="<?php echo $param_abs_path_si;?>body-upper.gif">&nbsp;</td>
<td width="20" height="20" background="<?php echo $param_abs_path_si;?>body-upper-right.gif">&nbsp;</td>
</tr>
<tr>
<td width="20" background="<?php echo $param_abs_path_si;?>body-left.gif">&nbsp;</td>
<td><span lang="en-us"><font size="4" face="Trebuchet MS"><?php echo $page_title;?></font></span></td>
<td width="20" background="<?php echo $param_abs_path_si;?>body-right.gif">&nbsp;</td>
</tr>
<tr>
<td width="20" background="<?php echo $param_abs_path_si;?>body-left.gif">&nbsp;</td>
<td><hr size="0" noshade></td>
<td width="20" background="<?php echo $param_abs_path_si;?>body-right.gif">&nbsp;</td>
</tr>
<tr>
<td width="20" background="<?php echo $param_abs_path_si;?>body-left.gif">&nbsp;</td>
<td>
<?php if($function_cur_index != -1) {?>
<table border="0" width="100%" cellspacing="3" cellpadding="3" style="border-collapse: collapse">
<tr>
<td width="24" align="center">
<img border="0" src="<?php echo $param_fun_menu[$function_cur_index][2];?>" width="24" height="24"></td>
<td><b>
<font face="Trebuchet MS" size="2"><?php echo $param_fun_menu[$function_cur_index][0];?></font></b></td>
</tr>
</table>
<?php }?>
</td>
<td width="20" background="<?php echo $param_abs_path_si;?>body-right.gif">&nbsp;</td>
</tr>
<tr>
<td width="20" background="<?php echo $param_abs_path_si;?>body-left.gif">&nbsp;</td>
<td>