<html dir="ltr">

<head>
<meta http-equiv="Content-Language" content="en-us">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<title>My Souktel - Under Construction</title>
</head>

<body>

<table border="0" width="100%" cellpadding="0" style="border-collapse: collapse" height="100%">
	<tr>
		<td>
		<p align="center">
		<img border="0" src="error.png" width="332" height="332"></p>
		<p align="center">&nbsp;</p>
		<p align="center"><b><font face="Trebuchet MS" size="6">Error Found</font></b></p>
		<p align="center"><font face="Trebuchet MS">For More Information Contact 
		Us At <a href="mailto:webmaster@mysouktel.com">webmaster@mysouktel.com</a></font></p>
		<p>&nbsp;</td>
	</tr>
</table>

</body>

</html>
