<p>

</td>
<td width="20" background="<?php echo $param_abs_path_si;?>body-right.gif">&nbsp;</td>
</tr>
<tr>
<td width="20" height="20" background="<?php echo $param_abs_path_si;?>body-lower-left.gif">&nbsp;</td>
<td height="20" background="<?php echo $param_abs_path_si;?>body-lower.gif">&nbsp;</td>
<td width="20" height="20" background="<?php echo $param_abs_path_si;?>body-lower-right.gif">&nbsp;</td>
</tr>
</table>