<?php
/**
 * Souktel v2.0
 * Developed By Tamer A. Qasim
 * +972(0)599358296
 * q.tamer@gmail.com
 */

$system_found = false;
$prefix_systems = array();
$systems_cnt = 0;

$prefix_systems[$systems_cnt][0] = strtoupper("SK"); //Prefix
$prefix_systems[$systems_cnt][1] = strtolower("mysouktel.com"); //URLwithout WWW, or IP Address
$systems_cnt++;

$prefix_systems[$systems_cnt][0] = strtoupper("ALC");
$prefix_systems[$systems_cnt][1] = strtolower("alc.mysouktel.com");
$systems_cnt++;

$prefix_systems[$systems_cnt][0] = strtoupper("QDS");
$prefix_systems[$systems_cnt][1] = strtolower("alquds.mysouktel.com");
$systems_cnt++;

$prefix_systems[$systems_cnt][0] = strtoupper("GAZA");
$prefix_systems[$systems_cnt][1] = strtolower("aljazeera.mysouktel.com");
$systems_cnt++;

$prefix_systems[$systems_cnt][0] = strtoupper("AMD");
$prefix_systems[$systems_cnt][1] = strtolower("amideast.mysouktel.com");
$systems_cnt++;

$prefix_systems[$systems_cnt][0] = strtoupper("ASL");
$prefix_systems[$systems_cnt][1] = strtolower("asala.mysouktel.com");
$systems_cnt++;

$prefix_systems[$systems_cnt][0] = strtoupper("BS");
$prefix_systems[$systems_cnt][1] = strtolower("btselem.mysouktel.com");
$systems_cnt++;

$prefix_systems[$systems_cnt][0] = strtoupper("RYD");
$prefix_systems[$systems_cnt][1] = strtolower("ryada.mysouktel.com");
$systems_cnt++;

$prefix_systems[$systems_cnt][0] = strtoupper("DWG");
$prefix_systems[$systems_cnt][1] = strtolower("dwg.mysouktel.com");
$systems_cnt++;

$prefix_systems[$systems_cnt][0] = strtoupper("EUH");
$prefix_systems[$systems_cnt][1] = strtolower("euh.mysouktel.com");
$systems_cnt++;

$prefix_systems[$systems_cnt][0] = strtoupper("HK");
$prefix_systems[$systems_cnt][1] = strtolower("hakawati.mysouktel.com");
$systems_cnt++;

$prefix_systems[$systems_cnt][0] = strtoupper("MC");
$prefix_systems[$systems_cnt][1] = strtolower("mercycorps.mysouktel.com");
$systems_cnt++;

$prefix_systems[$systems_cnt][0] = strtoupper("NK");
$prefix_systems[$systems_cnt][1] = strtolower("nayzak.mysouktel.com");
$systems_cnt++;

$prefix_systems[$systems_cnt][0] = strtoupper("RC");
$prefix_systems[$systems_cnt][1] = strtolower("rc.mysouktel.com");
$systems_cnt++;

$prefix_systems[$systems_cnt][0] = strtoupper("RI");
$prefix_systems[$systems_cnt][1] = strtolower("ri.mysouktel.com");
$systems_cnt++;

$prefix_systems[$systems_cnt][0] = strtoupper("SHRK");
$prefix_systems[$systems_cnt][1] = strtolower("sharek.mysouktel.com");
$systems_cnt++;

$prefix_systems[$systems_cnt][0] = strtoupper("BUZ");
$prefix_systems[$systems_cnt][1] = strtolower("buz.mysouktel.com");
$systems_cnt++;

$prefix_systems[$systems_cnt][0] = strtoupper("TN");
$prefix_systems[$systems_cnt][1] = strtolower("t3awon.mysouktel.com");
$systems_cnt++;

$prefix_systems[$systems_cnt][0] = strtoupper("TY");
$prefix_systems[$systems_cnt][1] = strtolower("tomorrowsyouth.mysouktel.com");
$systems_cnt++;

$prefix_systems[$systems_cnt][0] = strtoupper("WD");
$prefix_systems[$systems_cnt][1] = strtolower("wa3d.mysouktel.com");
$systems_cnt++;

$prefix_systems[$systems_cnt][0] = strtoupper("PVWC");
$prefix_systems[$systems_cnt][1] = strtolower("pvwc.mysouktel.com");
$systems_cnt++; 

$prefix_systems[$systems_cnt][0] = strtoupper("YMCA");
$prefix_systems[$systems_cnt][1] = strtolower("ymca.mysouktel.com");
$systems_cnt++;

$prefix_systems[$systems_cnt][0] = strtoupper("AAUJ");
$prefix_systems[$systems_cnt][1] = strtolower("aauj.mysouktel.com");
$systems_cnt++;

$prefix_systems[$systems_cnt][0] = strtoupper("JHD");
$prefix_systems[$systems_cnt][1] = strtolower("juhoud.mysouktel.com");
$systems_cnt++;

$prefix_systems[$systems_cnt][0] = strtoupper("EDC");
$prefix_systems[$systems_cnt][1] = strtolower("ruwwad.mysouktel.com");
$systems_cnt++;

$prefix_systems[$systems_cnt][0] = strtoupper("BEU");
$prefix_systems[$systems_cnt][1] = strtolower("beu.mysouktel.com");
$systems_cnt++;

$prefix_systems[$systems_cnt][0] = strtoupper("BYP");
$prefix_systems[$systems_cnt][1] = strtolower("byp.mysouktel.com");
$systems_cnt++;

$prefix_systems[$systems_cnt][0] = strtoupper("CHF");
$prefix_systems[$systems_cnt][1] = strtolower("chf.mysouktel.com");
$systems_cnt++;

$prefix_systems[$systems_cnt][0] = strtoupper("SK");
$prefix_systems[$systems_cnt][1] = strtolower("localhost");
$systems_cnt++;

$prefix_systems[$systems_cnt][0] = strtoupper("SHN");
$prefix_systems[$systems_cnt][1] = strtolower("aleatimad.mysouktel.com");
$systems_cnt++;

$prefix_systems[$systems_cnt][0] = strtoupper("MCI");
$prefix_systems[$systems_cnt][1] = strtolower("mcewomen.mysouktel.com");
$systems_cnt++;

$prefix_systems[$systems_cnt][0] = strtoupper("DEMO");
$prefix_systems[$systems_cnt][1] = strtolower("demo.mysouktel.com");
$systems_cnt++;

$prefix_systems[$systems_cnt][0] = strtoupper("GATE");
$prefix_systems[$systems_cnt][1] = strtolower("shababgate.mysouktel.com");
$systems_cnt++;

$prefix_systems[$systems_cnt][0] = strtoupper("HOLY");
$prefix_systems[$systems_cnt][1] = strtolower("holylandtrust.mysouktel.com");
$systems_cnt++;

$prefix_systems[$systems_cnt][0] = strtoupper("SUC");
$prefix_systems[$systems_cnt][1] = strtolower("suc.mysouktel.com");
$systems_cnt++;

$prefix_systems[$systems_cnt][0] = strtoupper("SOLO");
$prefix_systems[$systems_cnt][1] = strtolower("sologym.mysouktel.com");
$systems_cnt++;

$prefix_systems[$systems_cnt][0] = strtoupper("UTI");
$prefix_systems[$systems_cnt][1] = strtolower("uti.mysouktel.com");
$systems_cnt++;

$prefix_systems[$systems_cnt][0] = strtoupper("OGYM");
$prefix_systems[$systems_cnt][1] = strtolower("oxygengym.mysouktel.com");
$systems_cnt++;

$prefix_systems[$systems_cnt][0] = strtoupper("BZU");
$prefix_systems[$systems_cnt][1] = strtolower("bzu.mysouktel.com");
$systems_cnt++;

$prefix_systems[$systems_cnt][0] = strtoupper("CHP");
$prefix_systems[$systems_cnt][1] = strtolower("chp.mysouktel.com");
$systems_cnt++; 

for($i=0; $i<sizeof($prefix_systems); $i++)
{
    if(strtolower($_SERVER["HTTP_HOST"])==$prefix_systems[$i][1]
        || strtolower($_SERVER["HTTP_HOST"])=="www.".$prefix_systems[$i][1])
    {
        $extended_get1 = $prefix_systems[$i][0];
        $extended_get2 = sha1("6784567GFD".$extended_get1."214XdT00".$extended_get1."sktxx#21");
        $system_found = true;
        break;
    }
}

if(!$system_found) header('HTTP/1.0 404 Not Found');

?>
