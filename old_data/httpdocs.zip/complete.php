<?php
/**
 * Souktel v2.0
 * Developed By Tamer A. Qasim
 * +972(0)599358296
 * q.tamer@gmail.com
 */
?>


<html dir="ltr">

    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
        <meta http-equiv="Content-Language" content="ar-sa">
        <title>Souktel - Registration</title>
        <style type="text/css">
            .bold-input {
                width: 180; height: 30; font-family:Verdana; font-size:10pt; letter-spacing:1pt; font-weight:bold;
            }
        </style>

    </head>

    <body topmargin="0" leftmargin="0" rightmargin="0" bottommargin="0" marginwidth="0" marginheight="0">

        <div align="center">
            <table border="0" width="800" cellpadding="0" style="border-collapse: collapse">
                <tr>
                    <td>&nbsp;</td>
                </tr>
                <tr>
                    <td><img border="0" src="home-header.gif" width="800" height="69" usemap="#Map" />
                        <map name="Map">
                            <area shape="rect" coords="3,4,283,54" href="http://www.souktel.org/index.htm">
                            <area shape="rect" coords="292,20,350,52" href="http://www.souktel.org/About.htm">
                            <area shape="rect" coords="359,22,431,49" href="http://www.souktel.org/JobMatch.htm">
                            <area shape="rect" coords="443,19,499,45" href="http://www.souktel.org/AidLink.htm">
                            <area shape="rect" coords="510,17,592,47" href="http://www.souktel.org/Our%20Users.htm">
                            <area shape="rect" coords="600,22,669,45" href="http://www.souktel.org/Partners.htm">
                            <area shape="rect" coords="679,22,728,47" href="http://www.souktel.org/Media.htm">
                            <area shape="rect" coords="736,20,796,45" href="http://www.souktel.org/Contact.htm">
                        </map>
                    </td>
                </tr>
                <tr>
                    <td>&nbsp;</td>
                </tr>
                <tr>
                    <td><font face="Verdana" size="5" color="#632423">Registration - Complete!</font></td>
                </tr>
                <tr>
                    <td>&nbsp;</td>
                </tr>
                <tr>
                    <td>
                        <table border="0" width="800" cellpadding="0" style="border-collapse: collapse" background="images/system/body-background.gif">
                            <tr>
                                <td width="20" height="20" background="images/system/body-upper-left.gif">&nbsp;</td>
                                <td height="20" background="images/system/body-upper.gif">&nbsp;</td>
                                <td width="20" height="20" background="images/system/body-upper-right.gif">&nbsp;</td>
                            </tr>
                            <tr>
                                <td width="20" background="images/system/body-left.gif">&nbsp;</td>
                                <td>
                                    <font face="Verdana" size="2">
                                        Thank you for registering for JobMatch. You will be receiving a SMS message to your mobile phone asking you to activate your account.  Once your account is activated you will be able to create mini-CVs/Jobs and browse for jobs/CVs from your mobile phone or online.  Happy job hunting!!
                                    </font>
                                </td>
                                <td width="20" background="images/system/body-right.gif">&nbsp;</td>
                            </tr>
                            <tr>
                                <td width="20" height="20" background="images/system/body-lower-left.gif">&nbsp;</td>
                                <td height="20" background="images/system/body-lower.gif">&nbsp;</td>
                                <td width="20" height="20" background="images/system/body-lower-right.gif">&nbsp;</td>
                            </tr>
                        </table>
                    </td>
                </tr>
                <tr>
                    <td>&nbsp;</td>
                </tr>
                <tr>
                    <td><img border="0" src="home-footer.gif" width="800" height="27" /></td>
                </tr>
            </table>
        </div>

    </body>

</html>